package com.wf.example.ie_test.processing;

import com.workfusion.vds.sdk.api.nlp.model.IeDocument;
import com.workfusion.vds.sdk.api.nlp.processing.ProcessingException;
import com.workfusion.vds.sdk.api.nlp.processing.Processor;

import java.text.DecimalFormat;
import java.util.Collection;
import java.util.Optional;

import com.workfusion.vds.sdk.api.nlp.model.Field;//

public class PostProcessorExample implements Processor<IeDocument> {

	private static void operations(String x, Field field) {

		DecimalFormat doc = new DecimalFormat("#,###.00");
		 /*
         * Mis-interprted values are replaced "B"--->8   "G"--->6
         * "O"--->0 "I"--->1 "b"--->6 "l"--->1 "S"-->8
         */

		String m = x.replaceAll("B", "8").replaceAll("G", "6")
				.replaceAll("O", "0").replaceAll("I", "1")
				.replaceAll("l", "1").replaceAll("S", "8");

		field.setValue(doc.format(Float.parseFloat(m.toString())));
	}

	@Override
	public void process(IeDocument document) throws ProcessingException {

		// TODO add post-processing here
		// Field
		Optional<Field> fieldOp = document.findField("invoice_amount");
		Field amount = fieldOp.get();
		try {
			if (amount != null && amount.getValue() != null) {

				String value = amount.getValue();

				operations(value, amount);
			}

			Collection<Field> mycollect = document.findFields("order_total");
			for (Field field : mycollect) {
				if (field != null && field.getValue() != null) {
					String val = field.getValue();

					if (val.startsWith("S") || val.startsWith("B")) {
						val = val.substring(1, val.length());
					}

					operations(val, field);

				}
			}

		} catch (NumberFormatException ex) {
			document.remove(amount);

		}

	}

}
